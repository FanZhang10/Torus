Fan Zhang
100839154
2015/09/14

Control:
Up		Up arrow key
Down		Down arrow key
Left		Left arrow key
Right		Right arrow key
In		I
Out		O

The program only create 5 objects, player can control one of the object (blue). And another four object's position will randomly created.


