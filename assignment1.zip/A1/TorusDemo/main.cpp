#include <iostream>
#include <exception>
#include "ogre_application.h"
#include <cstdlib>

/* Macro for printing exceptions */
#define PrintException(exception_object)\
	std::cerr << exception_object.what() << std::endl

/* Main function that builds and runs the application */
int main(void){
    ogre_application::OgreApplication application;

	try {
		application.Init();
		application.CreateTorus("Torus0", "ObjectMaterial", Ogre::ColourValue (0.0,0.0,1.0));//blue, player control
		application.CreateTorus("Torus1", "ObjectMaterial", Ogre::ColourValue (1.0,0.0,0.0));
		application.CreateTorus("Torus2", "ObjectMaterial", Ogre::ColourValue (0.0,0.5,0.0));
		application.CreateTorus("Torus3", "ObjectMaterial", Ogre::ColourValue (0.5,0.5,0.0));
		application.CreateTorus("Torus4", "ObjectMaterial", Ogre::ColourValue (0.0,0.5,0.5));

		//application.SetupAnimation("Torus");
		application.loop();
		application.MainLoop();

	}
	catch (std::exception &e){
		PrintException(e);
	}

    return 0;
}
